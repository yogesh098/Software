package ass;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
public class LoadFile implements Interface{

BytePattern bytes=new BytePattern();
ArrayList<Byte> ByteFile=new ArrayList<Byte>();
String result="";
static String name;
static String path;
StringBuilder sb = new StringBuilder();
//calling method to select files
public void read(File file) throws IOException {
	/*
	 *  Important to use a buffered input stream, since reading a single byte at a time from file input stream would be very slow
	 */
	InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
	          /*
	           * the most recently read byte from the file.
	           */
	         int next;
	  /*
	   * read each byte of the file (until the end of the file has been reached), looking for any of the patterns
	   */
	  while ((next = inputStream.read()) != -1) {

	          /*
	           *  convert the value read into an 8 bit byte
	           */
		  byte nextByte = (byte)next; 
	        /*
	         * compare value of 'nextByte' with the next byte within the pattern to be detected
	         */
	        ByteFile.add(nextByte);
	  }
	  inputStream.close();
}

/*
 * method used to select file
 */
public void chooseFile(JMenuItem menuitem1) {
	menuitem1.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent evt) {
			JFileChooser fileChooser= new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			Component frame=null;
			if(fileChooser.showOpenDialog(frame)== JFileChooser.OPEN_DIALOG) {
				File file = fileChooser.getSelectedFile();
				//System.out.println("File name:"+file.getName());
				name = file.getName();
				path = file.getPath();
				GUI.File.setText("File / Directory Name  :  " + name);
				GUI.File1.setText("File / Directory Path  :  " + path);
				try {
					read(file);
					}
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				/*
				 * method called to compare 
				 */
				comparefile();
				}
			}
		});
	}
/*
 * Method to calling methods to load file
 */
public void chargeFile(JMenuItem menuitem2) {
	menuitem2.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent evt) {
			JFileChooser fileChooser1= new JFileChooser();
			//fileChooser1.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			Component frame=null;
			if(fileChooser1.showOpenDialog(frame)== JFileChooser.OPEN_DIALOG) {
				File file = fileChooser1.getSelectedFile();
				Scanner scanner = null;
				try {
					scanner = new Scanner(file);
					while (scanner.hasNextLine()) {
						String line = scanner.nextLine();
						bytes.parseLine(line);
						/*
						 *  process the line
						 */
						}
					} 
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				name = file.getName();
				path = file.getPath();
				//System.out.println("File name:"+file.getName());
				GUI.File.setText("File / Directory Name  :  " + name);
				GUI.File1.setText("File / Directory Path  :  " + path);
				}
			}
		});
	}
/*
 * Method used to compare file
 */
public void comparefile(){
	if(bytes.patternLength()>0) {
		bytes.nextPattern();
		result="";
		boolean status=false;
/*
 * you have to call nextPattern from BytePattern Class to initialize bytes
 * Using for loop to get patterns and select files
 */
for(int a=0; a<bytes.patternLength(); a++) {
   for(int r=0; r<ByteFile.size(); r++) {
		if(bytes.checkNext(ByteFile.get(r))){
        status=true;
        String hexPatt=bytes.hextoByte(a);
              int position =r-((hexPatt.length()/2)-1);
              result+="Pattern Found: "+ hexPatt+" , at offset: "+position+" (0x" +Integer.toHexString(position)+") " +" within the file.\n "+"\n";
              //System.out.println("Pattern Found:" );
             GUI.textarea.setText("Pattern Found !!");
         }
   }
 /*
  * Call nextPattern function from  BytePattern Class again to go to next Pattern
  */
   bytes.nextPattern();
}
//System.out.println(result);
GUI.textarea.setText(result);
if(status==false){
	result+="Pattern not found";
	}
}
else {
	JOptionPane.showMessageDialog(null, "Load a pattern file first(Load gara babu).");
	}
}

private int r(int i) {
	// TODO Auto-generated method stub
	return 0;
	}

@Override
public void chooseFile() {
	// TODO Auto-generated method stub
	
}

@Override
public void chargeFile() {
	// TODO Auto-generated method stub
	
}
}