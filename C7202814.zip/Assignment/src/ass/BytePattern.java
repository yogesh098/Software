package ass;
	import java.util.ArrayList;

	import javax.swing.JOptionPane;
	public class BytePattern {
		 /**
	     * The bytes within the pattern.
	     * 
		 * To store Patterns
		 */
	    private byte[] bytes;
	    /**
	     * The next position to be checked within the pattern's byte array.
	     *position in the arraylist
	     */
	    private int pattern= -1;
	    
	    static ArrayList<byte[]> patterns=new ArrayList<byte[]>();
	    
	    private boolean error;
	    
	    public boolean isError()
	    {
	    	return error;
	    }
	    
	    private int checkPos = 0;

	    /**
	     * Checks if the given value matches the next byte to be checked within the pattern.
	     *
	     * Each time this method is called it progresses to the next byte within the pattern, until the value does not match
	     * or the end of the pattern is reached (in which case a match has been found).
	     *
	     * @param value the value to be checked against the next byte in the pattern.
	     * @return true if the pattern has been matched, false if the pattern has not (yet) matched.
	     *
	     *to check next apttern value
	     */
	    public boolean checkNext(byte value) {
	        /*
	         *  check the given value against the next byte in the pattern (as determined by checkPos)
	         *  
	         * if the given byte does not match the next byte in the pattern then the match has failed, so reset checkPos and return false
	         * 
	         * if the given byte does match the next byte in the pattern, then
	         * 
             *  if not all bytes in the pattern have yet been checked return false (since a match has not YET been found)
             *  
             * if all the bytes in the pattern have been checked then then a full match is found, so return true (also reset checkPos for future checks)
             */
	    	if(value ==bytes[checkPos]) {
	    		checkPos++;
	    		if(checkPos == bytes.length)
	    		{
	    			checkPos=0;
	    			return true;
	    		}
	    		else
	        		return false;
	    	}
	    	else
	    	{
	    		checkPos=0;
	    		return false;
	    	}
	    	
	    }
	    /*
	     * Initializing default constructor
	     */
	    BytePattern()
	    {
	    }
	    /*
	     * Initializing constructor with parameter of byte array
	     */
	    BytePattern(byte[] bytes)
	    {
		this.bytes= bytes;
		}
	    /*
	     * Method used to calculate length
	     */
	    public int length()
	    {
	    	return patterns.get(pattern).length;
	    }
	    /*
	     * Method used to get pattern length
	     */
	    public int patternLength()
	    {
	    	return patterns.size();
	    }
	    /*
	     * Method used to know NextPattern
	     */
	    public void nextPattern()
	    {
	    	checkPos=0;
	    	pattern++;
	    	if(pattern<patterns.size()) {
	    	
	    	bytes=patterns.get(pattern);
	    	}
	    }
	    /*
	     * Methdo used to reset pattern
	     */
	    void reset()
	    {
	    	pattern=-1;
	    	checkPos=0;
	    }
	    /*
	     * Method used to clear pattern
	     */
	    static void clearPattern()
	    {
	    	patterns.clear();
	    }
	    /*
	     * Method used to add pattern
	     */
	void addPattern(byte[] pattern)
	{
		patterns.add(pattern);
	}
	/*
	 * me
	 */
	public byte[] getbytes()
	{
		if(pattern == -1) 
		{
			nextPattern();
		}
		return bytes;
	}
	/*
	 * Method for returning patterns
	 */
	public ArrayList<byte[]> getPatterns()
	{
		return patterns;
	}
	  /*
	   *  other methods, e.g. constructor to set pattern bytes
	   *  method to parse line of pattern file data (req 3) etc.
	   */
       /*
        * method use for the conversion of hex to byte .
        */
	public String hextoByte(int matcher){
		/*
		 * hex value is an string value taken to store value
		 */
		String hexvalue = "";
		for(byte equal : patterns.get(matcher)){
			String conversion = Integer.toHexString(equal);
			if(conversion.length() > 2){
				conversion = conversion.substring(6);
			}
			hexvalue = hexvalue + conversion;
		}
		return hexvalue;
	}
	/*
	 * Method used to break the line(pattern)
	 */
	void parseLine(String line)
	{
		error=false;
		String[] linesplit=line.split(" ");
		bytes=new byte[linesplit.length];
		int count=0;
		for(String linebyte : linesplit)
		{
			if(linebyte.length() !=2)
			{
				error=true;
			}
			try
			{
				byte test=(byte) Integer.parseInt(linebyte,16);
				bytes[count]=test;
				count++;
			}
			catch(NumberFormatException e)
			{
				error=true;
			}
		}
		addPattern(bytes);
		bytes=null;
			if(error)
			{
				JOptionPane.showMessageDialog(null, "Pattern break down","Error",-1);
			}	
		}
	}