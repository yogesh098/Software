package ass;
import org.junit.Assert;
import org.junit.Test;
public class JUnitTest {
	BytePattern BPattern=new BytePattern();
	byte[] firstPattern=new byte[]{0x41,0x42,0x43};
	@Test
	/*
	 * testing the added patterns
	 */
	public void testingAddPattern() throws Exception
	{
	       BPattern.addPattern(firstPattern);
	       Assert.assertArrayEquals(firstPattern, BPattern.getbytes() );
	}
	@Test
	/*
	 * for testing the clear patterns
	 */
	public void testingClearPattern() throws Exception
	{
	BytePattern.clearPattern();
	//Assert.assertEquals(null,BPattern.getbytes());
	}
}