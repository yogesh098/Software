package ass;
/*
 * Date : May 5 / 2020
 * This is the simple application where we can select file into Byte Value 
 */

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class GUI {
	private JFrame frame;
	LoadFile check = new LoadFile();
	static JTextArea textarea;
	static JScrollPane scroll;
	static JLabel File;
	static JLabel File1;
	static JLabel File2;
	static JPanel panel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Byte Pattern");
		frame.getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		frame.setBounds(100, 100, 606, 356);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();

		JMenu filemenu1 = new JMenu("File");
		filemenu1.setForeground(Color.RED);
		filemenu1.setMnemonic('f');
		filemenu1.setToolTipText("Click to know about the programmer");
		menuBar.add(filemenu1);
		
		JMenu filemenu2 = new JMenu("Help");
		filemenu2.setForeground(Color.RED);
		filemenu2.setMnemonic('h');
		filemenu2.setToolTipText("Click to know about the programmer");
		menuBar.add(filemenu2);
		
		JMenuItem menuitem1 = new JMenuItem("Select Files or Directories");
		menuitem1.setBackground(Color.BLACK);
		menuitem1.setForeground(Color.LIGHT_GRAY);
		menuitem1.setMnemonic('s');
		menuitem1.setToolTipText("Click to know about the programmer");
		filemenu1.add(menuitem1);
		check.chooseFile(menuitem1);

			
		JMenuItem menuitem2 = new JMenuItem("Load Pattern");
		menuitem2.setForeground(Color.LIGHT_GRAY);
		menuitem2.setBackground(Color.BLACK);
		menuitem2.setToolTipText("Click to know about the programmer");
		menuitem2.setMnemonic('l');
		filemenu1.add(menuitem2);
		check.chargeFile(menuitem2);
		
		JMenuItem item1 = new JMenuItem("Exit");
		item1.setForeground(Color.LIGHT_GRAY);
		item1.setBackground(Color.BLACK);
		item1.setBounds(15, 150, 50, 50);
		item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					int sty = JOptionPane.showConfirmDialog(null, "Sure to close ?","Really Closing me?",JOptionPane.YES_NO_OPTION);
	    			if (sty != 0)
	    			{
	    				JOptionPane.showConfirmDialog(null,"Welcome",null, JOptionPane.PLAIN_MESSAGE);
	    			}
	    			else {
	    				System.exit(0);
	    			}	
			}
		});
		//item1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.ALT_MASK));
		item1.setIcon(new ImageIcon("image/yogesh(icon).jpg"));
		item1.setMnemonic('e');
		item1.setToolTipText("Click to exit");
		filemenu1.add(item1);
		
		JButton exit = new JButton("Exit");
		exit.setForeground(Color.RED);
		exit.setMnemonic('e');
		exit.setToolTipText("Click to exit");
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					int sty = JOptionPane.showConfirmDialog(null, "Sure to close ?","Really Closing me?",JOptionPane.YES_NO_OPTION);
	    			if (sty != 0)
	    			{
	    				JOptionPane.showConfirmDialog(null,"Welcome",null, JOptionPane.PLAIN_MESSAGE);
	    			}
	    			else {
	    				System.exit(0);
	    			}
			}
		});
		//item1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.ALT_MASK));
		menuBar.add(exit);
		
		JMenuItem item2 = new JMenuItem("About");
		item2.setForeground(Color.LIGHT_GRAY);
		item2.setBackground(Color.BLACK);
		item2.setMnemonic('a');
		//item2.setIcon(new ImageIcon("images/yogesh(about).png"));
		item2.setToolTipText("Click to know about the programmer");
		item2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null, "Welcome, to this program where you can have data conversion. \n Yogesh Bahadur Singh \n @copyright 2019");				
			}
			});
		filemenu2.add(item2);
		frame.setJMenuBar(menuBar);
		
		textarea = new JTextArea("");
		textarea.setToolTipText("Where byte Patterns is displayed.");
	    textarea.setEditable(false);
	    textarea.setVisible(true);
	    textarea.setText(check.sb.toString());
		
		scroll = new JScrollPane(textarea);
		scroll.setToolTipText("Where byte Patterns is displayed.");
		scroll.setBounds(107, 124, 477, 164);
		scroll.setVisible(true);
		frame.getContentPane().setLayout(null);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		frame.getContentPane().add(scroll);
		
		File = new JLabel("Files / Directory Name  :   ");
		File.setForeground(Color.RED);
		File.setToolTipText("Files and Directory name are shown.");
		File.setBounds(10, 10, 500, 15);
		frame.getContentPane().add(File);
		
		File1 = new JLabel("Files / Directory Path  :   ");
		File1.setBackground(Color.WHITE);
		File1.setForeground(Color.RED);
		File1.setToolTipText("Files and Directory path are shown.");
		File1.setBounds(10, 49, 500, 15);
		frame.getContentPane().add(File1);
		
		File2 = new JLabel("Pattern Found : ");
		File2.setToolTipText("Pattern are shown.");
		File2.setBounds(10, 124, 596, 15);
		frame.getContentPane().add(File2);	
		return;
	}
}
