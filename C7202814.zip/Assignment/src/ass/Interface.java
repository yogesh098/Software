package ass;

public interface Interface {
	public void chooseFile();
	public void chargeFile();
	public void comparefile();	
	}
